imagem_bola = pygame.image.load(r"C:\Users\Pe\Downloads\ChatGPT Image 14 de mai. de 2025, 08_12_27.png").convert()


imagem_gol = pygame.image.load(r"C:\Users\Pe\Downloads\ChatGPT Image 14 de mai. de 2025, 08_44_04.png").convert()

imagem_patrocinadores = pygame.image.load(r"link").convert()


imagem_goleiro = pygame.image.load(r"link").convert()
